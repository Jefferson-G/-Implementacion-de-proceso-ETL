// JavaScript Document
// select all elements
const start = document.getElementById("start");
const quiz = document.getElementById("quiz");
const question = document.getElementById("question");
const qImg = document.getElementById("qImg");
const choiceA = document.getElementById("A");
const choiceB = document.getElementById("B");
const choiceC = document.getElementById("C");
const counter = document.getElementById("counter");
const timeGauge = document.getElementById("timeGauge");
const progress = document.getElementById("progress");
const scoreDiv = document.getElementById("scoreContainer");

// create our questions
let questions = [
    {
        question : "La acidificaci\u00F3n se debe a la emisi\u00F3n de? ",
        imgSrc : "img/microscopio.png",
        choiceA : "Ox\u00EDgeno.",
        choiceB : "Agua y ox\u00EDgeno.",
        choiceC : "Di\u00F3xido y Azufre.",
        correct : "C"
    },{
        question : "Es contaminaci\u00F3n atmosf\u00E9rica ",
        imgSrc : "img/microscopio.png",
        choiceA : "Las part\u00EDculas se manifiestan como polvo.",
        choiceB : "El humo que se respira en la calle.",
        choiceC : "Reciclar fundas.",
        correct : "C"
    },{
        question : "Cu\u00E1l fue el cient\u00EDfico que examino una l\u00E1mina de corcho en el microscopio y observ\u00E9 una serie de cerdillas? ",
        imgSrc : "img/microscopio.png",
        choiceA : "Pasteur.",
        choiceB : "Robert Hooke.",
        choiceC : "Francisco Red\u00ED.",
        correct : "B"
    },{
        question : "Si se desea fundir un cubo de hielo a agua l\u00EDquida se debe ______ ",
        imgSrc : "img/microscopio.png",
        choiceA : "Temperatura en -5�C.",
        choiceB : "Quitar energ\u00EDa como calor.",
        choiceC : "Agregar energ\u00EDa como calor.",
        correct : "C"
    },{
        question : "Los topos, al vivir bajo tierra, en la oscuridad, se han adaptado perdiendo los ojos'', es una afirmacion tipicamente: ",
        imgSrc : "img/microscopio.png",
        choiceA : "Neodarwinista",
        choiceB : "Darwinista",
        choiceC : "Lamarckista",
        correct : "C"
    },{
        question : "La litosfera comprende: ",
        imgSrc : "img/microscopio.png",
        choiceA : "La corteza y parte del manto superior.",
        choiceB : "S\u00F3lo el manto.",
        choiceC : "La corteza continental.",
        correct : "A"
    },{
        question : "Los organismos ______ elaboran alimento para si mismo, utilizando sustancias ______ en presencia de ______ ",
        imgSrc : "img/microscopio.png",
        choiceA : "Heterotrofos - org\u00E1nicas - energ\u00EDa activa.",
        choiceB : "Fotosint\u00E9ticos - inorg\u00E1nicas - luz solar.",
        choiceC : "Descomponedores - org\u00E1nicas - radiaci\u00F3n solar.",
        correct : "B"
    },{
        question : "El ______ de poblaciones en un mismo ______ se define como ______ ",
        imgSrc : "img/microscopio.png",
        choiceA : "Grupo - h\u00E1bitat - ecosistema.",
        choiceB : "Conjunto - nicho - comunidad.",
        choiceC : "Conjunto - h\u00E1bitat - comunidad.",
        correct : "C"
    },{
        question : "La teor\u00EDa m\u00E1s aceptada sobre el origen de la Tierra sostiene que nuestro planeta se origin\u00F3: ",
        imgSrc : "img/microscopio.png",
        choiceA : "Por acumulaci\u00F3n de materia espacial.",
        choiceB : "Luego de una gran explosi\u00F3n.",
        choiceC : "Ya estaba formada desde siempre.",
        correct : "A"
    },{
        question : "De acuerdo con la teor\u00EDa de la evoluci\u00F3n de Darwin. La supervivencia de una especia se basa en: ",
        imgSrc : "img/microscopio.png",
        choiceA : "Nada",
        choiceB : "La capacidad de adaptaci\u00F3n",
        choiceC : "Las fuentes de alimento.",
        correct : "B"
    },{
        question : "Entre la bi\u00F3sfera terrestre y el resto del universo hay un intercambio de... ",
        imgSrc : "img/microscopio.png",
        choiceA : "Gases",
        choiceB : "Energ\u00FDa",
        choiceC : "Materia",
        correct : "B"
    },{
        question : "La respiraci\u00F3n celular se da en qu\u00E9 parte de la c\u00E9lula? ",
        imgSrc : "img/microscopio.png",
        choiceA : "Mitocondria.",
        choiceB : "Ribosoma.",
        choiceC : "Citoplasma.",
        correct : "A"
    }
	
	
	
	
];

// create some variables

const lastQuestion = questions.length - 1;
let runningQuestion = 0;
let count = 0;
const questionTime = 122; // 10s
const gaugeWidth = 150; // 150px
const gaugeUnit = gaugeWidth / questionTime;
let TIMER;
let score = 0;

// render a question
function renderQuestion(){
    let q = questions[runningQuestion];
    
    question.innerHTML = "<p>"+ q.question +"</p>";
    qImg.innerHTML = "<img src="+ q.imgSrc +">";
    choiceA.innerHTML = q.choiceA;
    choiceB.innerHTML = q.choiceB;
    choiceC.innerHTML = q.choiceC;
}

start.addEventListener("click",startQuiz);

// start quiz
function startQuiz(){
    start.style.display = "none";
    renderQuestion();
    quiz.style.display = "block";
    renderProgress();
    renderCounter();
    TIMER = setInterval(renderCounter,1000); // 1000ms = 1s
}

// render progress
function renderProgress(){
    for(let qIndex = 0; qIndex <= lastQuestion; qIndex++){
        progress.innerHTML += "<div class='prog' id="+ qIndex +"></div>";
    }
}

// counter render

function renderCounter(){
    if(count <= questionTime){
        counter.innerHTML = count;
        timeGauge.style.width = count * gaugeUnit + "px";
        count++
    }else{
        count = 0;
        // change progress color to red
        answerIsWrong();
        if(runningQuestion < lastQuestion){
            runningQuestion++;
            renderQuestion();
        }else{
            // end the quiz and show the score
            clearInterval(TIMER);
            scoreRender();
        }
    }
}

// checkAnwer

function checkAnswer(answer){
    if( answer == questions[runningQuestion].correct){
        // answer is correct
        score++;
        // change progress color to green
        answerIsCorrect();
    }else{
        // answer is wrong
        // change progress color to red
        answerIsWrong();
    }
    count = 0;
    if(runningQuestion < lastQuestion){
        runningQuestion++;
        renderQuestion();
    }else{
        // end the quiz and show the score
        clearInterval(TIMER);
        scoreRender();
    }
}

// answer is correct
function answerIsCorrect(){
    document.getElementById(runningQuestion).style.backgroundColor = "#0f0";
}

// answer is Wrong
function answerIsWrong(){
    document.getElementById(runningQuestion).style.backgroundColor = "#f00";
}

// score render
function scoreRender(){
    scoreDiv.style.display = "block";
    
    // calculate the amount of question percent answered by the user
    const scorePerCent = Math.round(100 * score/questions.length);
    
    // choose the image based on the scorePerCent
    let img = (scorePerCent >= 80) ? "img/5.png" :
              (scorePerCent >= 60) ? "img/4.png" :
              (scorePerCent >= 40) ? "img/3.png" :
              (scorePerCent >= 20) ? "img/2.png" :
              "img/1.png";
    
    scoreDiv.innerHTML = "<img src="+ img +">";
    scoreDiv.innerHTML += "<p>"+ scorePerCent +"%</p>";
}






