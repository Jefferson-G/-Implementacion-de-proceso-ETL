// JavaScript Document


// select all elements
const start = document.getElementById("start");
const quiz = document.getElementById("quiz");
const question = document.getElementById("question");
const qImg = document.getElementById("qImg");
const choiceA = document.getElementById("A");
const choiceB = document.getElementById("B");
const choiceC = document.getElementById("C");
const counter = document.getElementById("counter");
const timeGauge = document.getElementById("timeGauge");
const progress = document.getElementById("progress");
const scoreDiv = document.getElementById("scoreContainer");

// create our questions
let questions = [
    {
        question : "Si julio ahorra siempre la quinta parte de su sueldo y hasta el mes pasado ahorro USD 200, despues de un aumento ahorra USD 300, Cuanto USD le aumentaron a su salario?",
        imgSrc : "img/calculadora.png",
        choiceA : "400",
        choiceB : "500",
        choiceC : "100",
        correct : "B"
    },{
        question : "Se compra cinco decenas de cartulinas, 8 hojas de papel y 12 paquetes de papeletas en USD 13,10. Si cada cartulina cuesta USD 0,15 y cada hoja  USD 0,25; el costo de cada paquete del papeleta es: ",
        imgSrc : "img/calculadora.png",
        choiceA : "0.175",
        choiceB : "0.30",
        choiceC : "3.60",
        correct : "B"
    },{
        question : "Complete la sucesion. 2y, 4w, 8u,__,32q.",
        imgSrc : "img/calculadora.png",
        choiceA : "16s",
        choiceB : "16r",
        choiceC : "24s",
        correct : "A"
    },{
        question : "La altura de un edificio que proyecta una sombra de 45m, a la misma hora que un palo de 1,2 m proyecta una sombra de 1,1m es:",
        imgSrc : "img/calculadora.png",
        choiceA : "49.10 m",
        choiceB : "41.25",
        choiceC : "37.5",
        correct : "A"
    },{
        question : "Cu\u00E1ntos vasos de 250 mililitros se puede llenar desde un recipiente con 5 litros de jugo de naranja?",
        imgSrc : "img/calculadora.png",
        choiceA : "4",
        choiceB : "50",
        choiceC : "20",
        correct : "C"
    },{
        question : "Una persona compra tres docenas de l\u00E1pices, 12 cuadernos y 10 resmas de papel en USD 62,4. Si cada l\u00E1piz cuesta USD0,30 y cada cuaderno USD 1,80; el costo de cada resma es:",
        imgSrc : "img/calculadora.png",
        choiceA : "1,0",
        choiceB : "3,0",
        choiceC : "1,2",
        correct : "B"
    },{
        question :"Complete la secuencia. A, C, __, H, K, M, O,"

,
        imgSrc : "img/calculadora.png",
        choiceA : "F",
        choiceB : "D",
        choiceC : "E",
        correct : "A"
    },{
        question : "Si 2 personas pintan una escuela en 72 horas, Cu\u00E1nto tiempo demorar\u00E1n 3 personas en pintar la misma escuela?",
        imgSrc : "img/calculadora.png",
        choiceA : "2",
        choiceB : "49",
        choiceC : "13",
        correct : "B"
    }
	
	
	
	
];

// create some variables

const lastQuestion = questions.length - 1;
let runningQuestion = 0;
let count = 0;
const questionTime = 122; // 10s
const gaugeWidth = 150; // 150px
const gaugeUnit = gaugeWidth / questionTime;
let TIMER;
let score = 0;

// render a question
function renderQuestion(){
    let q = questions[runningQuestion];
    
    question.innerHTML = "<p>"+ q.question +"</p>";
    qImg.innerHTML = "<img src="+ q.imgSrc +">";
    choiceA.innerHTML = q.choiceA;
    choiceB.innerHTML = q.choiceB;
    choiceC.innerHTML = q.choiceC;
}

start.addEventListener("click",startQuiz);

// start quiz
function startQuiz(){
    start.style.display = "none";
    renderQuestion();
    quiz.style.display = "block";
    renderProgress();
    renderCounter();
    TIMER = setInterval(renderCounter,1000); // 1000ms = 1s
}

// render progress
function renderProgress(){
    for(let qIndex = 0; qIndex <= lastQuestion; qIndex++){
        progress.innerHTML += "<div class='prog' id="+ qIndex +"></div>";
    }
}

// counter render

function renderCounter(){
    if(count <= questionTime){
        counter.innerHTML = count;
        timeGauge.style.width = count * gaugeUnit + "px";
        count++
    }else{
        count = 0;
        // change progress color to red
        answerIsWrong();
        if(runningQuestion < lastQuestion){
            runningQuestion++;
            renderQuestion();
        }else{
            // end the quiz and show the score
            clearInterval(TIMER);
            scoreRender();
        }
    }
}

// checkAnwer

function checkAnswer(answer){
    if( answer == questions[runningQuestion].correct){
        // answer is correct
        score++;
        // change progress color to green
        answerIsCorrect();
    }else{
        // answer is wrong
        // change progress color to red
        answerIsWrong();
    }
    count = 0;
    if(runningQuestion < lastQuestion){
        runningQuestion++;
        renderQuestion();
    }else{
        // end the quiz and show the score
        clearInterval(TIMER);
        scoreRender();
    }
}

// answer is correct
function answerIsCorrect(){
    document.getElementById(runningQuestion).style.backgroundColor = "#0f0";
}

// answer is Wrong
function answerIsWrong(){
    document.getElementById(runningQuestion).style.backgroundColor = "#f00";
}

// score render
function scoreRender(){
    scoreDiv.style.display = "block";
    
    // calculate the amount of question percent answered by the user
    const scorePerCent = Math.round(100 * score/questions.length);
    
    // choose the image based on the scorePerCent
    let img = (scorePerCent >= 80) ? "img/5.png" :
              (scorePerCent >= 60) ? "img/4.png" :
              (scorePerCent >= 40) ? "img/3.png" :
              (scorePerCent >= 20) ? "img/2.png" :
              "img/1.png";
    
    scoreDiv.innerHTML = "<img src="+ img +">";
    scoreDiv.innerHTML += "<p>"+ scorePerCent +"%</p>";
}