<?php session_start();

if (isset($_SESSION['usuario'])) {
	require 'views/proj/Proyecto_integrador.php';
	
} else {
	header('Location: login.php');
}

?>