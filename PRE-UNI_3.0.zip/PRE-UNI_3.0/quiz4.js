// JavaScript Document
// select all elements
const start = document.getElementById("start");
const quiz = document.getElementById("quiz");
const question = document.getElementById("question");
const qImg = document.getElementById("qImg");
const choiceA = document.getElementById("A");
const choiceB = document.getElementById("B");
const choiceC = document.getElementById("C");
const counter = document.getElementById("counter");
const timeGauge = document.getElementById("timeGauge");
const progress = document.getElementById("progress");
const scoreDiv = document.getElementById("scoreContainer");

// create our questions
let questions = [
    {
        question : "Cu\u00E1ndo se independiz\u00F3 Loja?",
        imgSrc : "img/sociales.png",
        choiceA : "El 18 de noviembre de 1820",
        choiceB : "El 8 de septiembre de 1822",
        choiceC : "El 8 de diciembre de 1820",
        correct : "A"
    },{
        question : "La cultura precolombina asentada en Manab\u00ED, Santa Elena y Guayas, famosa por sus 'venus' de cer\u00E1mica es:",
        imgSrc : "img/sociales.png",
        choiceA : "Nazca",
        choiceB : "Valdivia",
        choiceC : "Machalilla",
        correct : "B"
    },{
        question : "El documento que re\u00FAne todas las leyes de un Estado se llama: ",
        imgSrc : "img/sociales.png",
        choiceA : "Constituci\u00F3n",
        choiceB : "Asamblea",
        choiceC : "Normas",
        correct : "A"
    },{
        question : "Qu\u00E9 era el ayllu?",
        imgSrc : "img/sociales.png",
        choiceA : "Un grupo de familias",
        choiceB : "Un sacerdote",
        choiceC : "Un instrumento musical",
        correct : "A"
    },{
        question : "Qui\u00E9n es el autor de la novela UN HOMBRE MUERTO A PUNTAPIES",
        imgSrc : "img/sociales.png",
        choiceA : "Pablo Palacio",
        choiceB : "Pablo Neruda",
        choiceC : "Alejandro Carrion",
        correct : "A"
    },{
        question :"George Washington fue presidente de:"

,
        imgSrc : "img/P7.PNG",
        choiceA : "Estados Unidos",
        choiceB : "Mexico",
        choiceC : "Francia",
        correct : "A"
    },{
        question : "La guerra del Cenepa se di\u00F3 en la presidencia de:",
        imgSrc : "img/sociales.PNG",
        choiceA : "Sixto Duran Ballen",
        choiceB : "Jamil Mahuad",
        choiceC : "Leon Febres Cordero",
        correct : "A"
    },{
        question : "La carta de la esclavitud se da en.........de Juan J\u00F3se FlOres",
        imgSrc : "img/sociales.PNG",
        choiceA : "La primera presidencia",
        choiceB : "La segunda presidencia",
        choiceC : "La tercera presidencia",
        correct : "B"
    },{
        question : "Qu\u00E9 provincias comparten el bosque petrificado de PUYANGO",
        imgSrc : "img/sociales.PNG",
        choiceA : "El Oro y Loja",
        choiceB : "Azuay y el Oro",
        choiceC : "Zamora y Loja",
        correct : "A"
    },{
        question : "En qu\u00E9 casa se reunieron los criollos para organizar la Junta Suprema de Quito",
        imgSrc : "img/sociales.PNG",
        choiceA : "Jose de Antepara",
        choiceB : "Manuela Ca�izares",
        choiceC : "Eugenio Espejo",
        correct : "C"
    },{
        question : "El rio Amazonas desemboca en",
        imgSrc : "img/sociales.PNG",
        choiceA : "Mar Caspio",
        choiceB : "Oceano Atl\u00E1ntico",
        choiceC : "Oceano Pac\u00EDfico",
        correct : "B"
    },{
        question : "Durante la primera guerra mundial, rusia dej\u00F3 la alianza e inglaterra debido a:",
        imgSrc : "img/sociales.PNG",
        choiceA : "La revolucion socialista",
        choiceB : "La derrota aliada",
        choiceC : "La invasion de los alemanes",
        correct : "A"
    },{
        question : "Qu\u00E9 colores identifican la vestimenta de los Saraguros......",
        imgSrc : "img/sociales.PNG",
        choiceA : "Blanco Negro",
        choiceB : "Blanco Azul",
        choiceC : "Azul Verde",
        correct : "A"
    },{
        question : "Lat\u00EDn era la lengua que hablamos los:",
        imgSrc : "img/sociales.PNG",
        choiceA : "Romanos",
        choiceB : "Griegos",
        choiceC : "Persas",
        correct : "A"
    },{
        question : "Qu\u00E9 pais no pertenece al conosur de America",
        imgSrc : "img/sociales.PNG",
        choiceA : "Colombia",
        choiceB : "Argentina",
        choiceC : "Chile",
        correct : "A"
    },{
        question : "Los amantes de Sumpa, son los restos arqueologicos encontrados en:",
        imgSrc : "img/sociales.PNG",
        choiceA : "Sumbagua",
        choiceB : "Manta",
        choiceC : "Santa Elena",
        correct : "D"
    }
	
	
	
	
	
];

// create some variables

const lastQuestion = questions.length - 1;
let runningQuestion = 0;
let count = 0;
const questionTime = 122; // 10s
const gaugeWidth = 150; // 150px
const gaugeUnit = gaugeWidth / questionTime;
let TIMER;
let score = 0;

// render a question
function renderQuestion(){
    let q = questions[runningQuestion];
    
    question.innerHTML = "<p>"+ q.question +"</p>";
    qImg.innerHTML = "<img src="+ q.imgSrc +">";
    choiceA.innerHTML = q.choiceA;
    choiceB.innerHTML = q.choiceB;
    choiceC.innerHTML = q.choiceC;
}

start.addEventListener("click",startQuiz);

// start quiz
function startQuiz(){
    start.style.display = "none";
    renderQuestion();
    quiz.style.display = "block";
    renderProgress();
    renderCounter();
    TIMER = setInterval(renderCounter,1000); // 1000ms = 1s
}

// render progress
function renderProgress(){
    for(let qIndex = 0; qIndex <= lastQuestion; qIndex++){
        progress.innerHTML += "<div class='prog' id="+ qIndex +"></div>";
    }
}

// counter render

function renderCounter(){
    if(count <= questionTime){
        counter.innerHTML = count;
        timeGauge.style.width = count * gaugeUnit + "px";
        count++
    }else{
        count = 0;
        // change progress color to red
        answerIsWrong();
        if(runningQuestion < lastQuestion){
            runningQuestion++;
            renderQuestion();
        }else{
            // end the quiz and show the score
            clearInterval(TIMER);
            scoreRender();
        }
    }
}

// checkAnwer

function checkAnswer(answer){
    if( answer == questions[runningQuestion].correct){
        // answer is correct
        score++;
        // change progress color to green
        answerIsCorrect();
    }else{
        // answer is wrong
        // change progress color to red
        answerIsWrong();
    }
    count = 0;
    if(runningQuestion < lastQuestion){
        runningQuestion++;
        renderQuestion();
    }else{
        // end the quiz and show the score
        clearInterval(TIMER);
        scoreRender();
    }
}

// answer is correct
function answerIsCorrect(){
    document.getElementById(runningQuestion).style.backgroundColor = "#0f0";
}

// answer is Wrong
function answerIsWrong(){
    document.getElementById(runningQuestion).style.backgroundColor = "#f00";
}

// score render
function scoreRender(){
    scoreDiv.style.display = "block";
    
    // calculate the amount of question percent answered by the user
    const scorePerCent = Math.round(100 * score/questions.length);
    
    // choose the image based on the scorePerCent
    let img = (scorePerCent >= 80) ? "img/5.png" :
              (scorePerCent >= 60) ? "img/4.png" :
              (scorePerCent >= 40) ? "img/3.png" :
              (scorePerCent >= 20) ? "img/2.png" :
              "img/1.png";
    
    scoreDiv.innerHTML = "<img src="+ img +">";
    scoreDiv.innerHTML += "<p>"+ scorePerCent +"%</p>";
}