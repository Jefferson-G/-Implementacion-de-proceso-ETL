// JavaScript Document


// select all elements
const start = document.getElementById("start");
const quiz = document.getElementById("quiz");
const question = document.getElementById("question");
const qImg = document.getElementById("qImg");
const choiceA = document.getElementById("A");
const choiceB = document.getElementById("B");
const choiceC = document.getElementById("C");
const counter = document.getElementById("counter");
const timeGauge = document.getElementById("timeGauge");
const progress = document.getElementById("progress");
const scoreDiv = document.getElementById("scoreContainer");

// create our questions
let questions = [
    {
        question : "Tres obreros cavan en 24 horas una zanja de 12m. Cu\u00E1ntos metros cavar\u00F3n en 12 horas 9 obreros?",
        imgSrc : "img/calculadora.png",
        choiceA : "18",
        choiceB : "6",
        choiceC : "2",
        correct : "A"
    },{
        question : "Si se debe realizar, con los n\u00FAmeros del 1 al 5, c\u00F3digos de dos d\u00EDgitos para una tienda de ropa sin que se repitan sus d\u00EDgitos, cu\u00E1ntos c\u00F3digos se puede formar? ",
        imgSrc : "img/calculadora.png",
        choiceA : "10",
        choiceB : "20",
        choiceC : "Wrong",
        correct : "120"
    },{
        question : "Tatiana debe pagar su pr\u00E9stamo en 8 cuotas que aumentan en 6 d\u00F3lares cada mes. Si la cuota inicial es de 6 d\u00F3lares, entonces cu\u00E1nto gastar\u00F3 en total? ",
        imgSrc : "img/calculadora.png",
        choiceA : "156",
        choiceB : "180",
        choiceC : "216",
        correct : "C"
    },{
        question : "La importaci\u00F3n de un equipo cuesta $600, adicionalmente, se paga por transporte el 20%. Sobre este nuevo valor se paga un 5% del valor del seguro.Identifique el valor en dolares que se debe pagar",
        imgSrc : "img/calculadora.png",
        choiceA : "156",
        choiceB : "180",
        choiceC : "216",
        correct : "C"
    },{
        question : "Identifique la consecuencia de la liberaci\u00F3n de di\u00F3xido de carbono en la atm\u00F3sfera, producida por la combusti\u00F3n de gasolina, petr\u00F3leo, carb\u00F3n y emisiones de f\u00E1bricas. ",
        imgSrc : "img/microscopio.png",
        choiceA : "Lluvia acida",
        choiceB : "Lixiviacion",
        choiceC : "Efecto ivernadero",
        correct : "C"
    },{
        question : "Identifica una consecuencia del exceso de riego en el suelo ",
        imgSrc : "img/microscopio.png",
        choiceA : "Salinizaci\u00F3n",
        choiceB : "Eutrofizaci\u00F3n",
        choiceC : "Alcalinizaci\u00F3n",
        correct : "A"
    },{
        question :"De acuerdo a la siguiente imagen, cu\u00E1l es la causa social que contribuye al deterioro ambiental del mundo"

,
        imgSrc : "img/P7.PNG",
        choiceA : "Explotaci\u00F3n de recurso",
        choiceB : "Las pestes y enfermedades",
        choiceC : "Los conflictos de gobierno",
        correct : "C"
    },{
        question : "El concurso de una feria consiste en predecir el siguiente n\u00FAmero que aparecer\u00E1 en la ruleta. Si x es el pr\u00F3ximo n\u00FAmero en aparecer",
        imgSrc : "img/P4.PNG",
        choiceA : "2",
        choiceB : "49",
        choiceC : "13",
        correct : "B"
    }
	
	
	
	
];

// create some variables

const lastQuestion = questions.length - 1;
let runningQuestion = 0;
let count = 0;
const questionTime = 122; // 10s
const gaugeWidth = 150; // 150px
const gaugeUnit = gaugeWidth / questionTime;
let TIMER;
let score = 0;

// render a question
function renderQuestion(){
    let q = questions[runningQuestion];
    
    question.innerHTML = "<p>"+ q.question +"</p>";
    qImg.innerHTML = "<img src="+ q.imgSrc +">";
    choiceA.innerHTML = q.choiceA;
    choiceB.innerHTML = q.choiceB;
    choiceC.innerHTML = q.choiceC;
}

start.addEventListener("click",startQuiz);

// start quiz
function startQuiz(){
    start.style.display = "none";
    renderQuestion();
    quiz.style.display = "block";
    renderProgress();
    renderCounter();
    TIMER = setInterval(renderCounter,1000); // 1000ms = 1s
}

// render progress
function renderProgress(){
    for(let qIndex = 0; qIndex <= lastQuestion; qIndex++){
        progress.innerHTML += "<div class='prog' id="+ qIndex +"></div>";
    }
}

// counter render

function renderCounter(){
    if(count <= questionTime){
        counter.innerHTML = count;
        timeGauge.style.width = count * gaugeUnit + "px";
        count++
    }else{
        count = 0;
        // change progress color to red
        answerIsWrong();
        if(runningQuestion < lastQuestion){
            runningQuestion++;
            renderQuestion();
        }else{
            // end the quiz and show the score
            clearInterval(TIMER);
            scoreRender();
        }
    }
}

// checkAnwer

function checkAnswer(answer){
    if( answer == questions[runningQuestion].correct){
        // answer is correct
        score++;
        // change progress color to green
        answerIsCorrect();
    }else{
        // answer is wrong
        // change progress color to red
        answerIsWrong();
    }
    count = 0;
    if(runningQuestion < lastQuestion){
        runningQuestion++;
        renderQuestion();
    }else{
        // end the quiz and show the score
        clearInterval(TIMER);
        scoreRender();
    }
}

// answer is correct
function answerIsCorrect(){
    document.getElementById(runningQuestion).style.backgroundColor = "#0f0";
}

// answer is Wrong
function answerIsWrong(){
    document.getElementById(runningQuestion).style.backgroundColor = "#f00";
}

// score render
function scoreRender(){
    scoreDiv.style.display = "block";
    
    // calculate the amount of question percent answered by the user
    const scorePerCent = Math.round(100 * score/questions.length);
    
    // choose the image based on the scorePerCent
    let img = (scorePerCent >= 80) ? "img/5.png" :
              (scorePerCent >= 60) ? "img/4.png" :
              (scorePerCent >= 40) ? "img/3.png" :
              (scorePerCent >= 20) ? "img/2.png" :
              "img/1.png";
    
    scoreDiv.innerHTML = "<img src="+ img +">";
    scoreDiv.innerHTML += "<p>"+ scorePerCent +"%</p>";
}

