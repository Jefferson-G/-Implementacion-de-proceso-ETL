<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no,
	 initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	 <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	 <link rel="stylesheet" href="css/style.css">
	<title>Registrate</title>
		 
</head>
<img src="img/logo.png"  style="position:absolute; margin-left:330px;  margin-top:-30px; " >
 <!--==========================
      About Us Section
    ============================-->
	<br>
	 <h1 style="margin-left:140px; margin-top:20px;"> PRE-UNI  </h1>
	 <br>

    <section id="about">

       <div class="s"  style="margin-left:15px; margin-top:-40px;"><br>
              <img src="img/jovens.png" border="3px" width="330px" height="400px">           
  </div>
            <div class="about-content" style="margin-left:360px; margin-top:-470px;">
             <br>
              <h3><b>El mejor preuniversitario en línea,<br>gratuito, actualizado, y con todo<br> lo que necesitas para rendir<br> el examen ser bachiller y  poder <br>escoger la carrera de tus sueños!!<br><br>Empieza ahora mismo con un breve <br>registro de datos.</b>  </h3>
             
              <p><b>¿Por qué estudiar con nosotros?</b></p>
              <ul>
                <li><i class="ion-android-checkmark-circle"></i> Simuladores muy simulares al examen </li>
                <li><i class="ion-android-checkmark-circle"></i> Presentacion de pruebas liberadas del año vijente</li>
                <li><i class="ion-android-checkmark-circle"></i> Tutoriales para explicarte los ejercicios de la prueba.</li>
              </ul>
            </div>
          
        </div>
      </div>

    </section>









<body class="bodix" >
	<div class="contenedorrl"  >
	<br>
		<h1 class="titulo">Registrate en <br> PRE-UNI</h1>
		<center><img src="img/regis.png"></center>
		<hr class="border">

		<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" class="formulario" name="login">
			<div class="form-group">
				<i class="icono izquierda fa fa-user"></i><input type="text" name="usuario" class="usuario" placeholder="Correo*" >
			</div>

			<div class="form-group">
				<i class="icono izquierda fa fa-lock"></i><input type="password" name="password" class="password" placeholder="Contraseña*">
			</div>

			<div class="form-group">
				<i class="icono izquierda fa fa-lock"></i><input type="password" name="password2" class="password_btn" placeholder="Repetir Contraseña*">
				<i class="submit-btn fa fa-arrow-right" onClick="login.submit()"></i>
			</div>
			
				
			<?php if(!empty($errores)): ?>
				<div class="error">
					<ul>
						<?php echo $errores; ?>
					</ul>
				</div>
			<?php endif; ?>
			
		</form>

		<p class="texto-registrate">
			¿ Ya tienes cuenta ?
			<a href="login.php">Iniciar Sesión</a>
		</p>
	</div>
</body>
</html>