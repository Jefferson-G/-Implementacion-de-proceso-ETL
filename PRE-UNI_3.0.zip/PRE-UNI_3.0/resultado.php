<!DOCTYPE html >
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>PRE-UNI</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Favicons -->
  <link href="img/logito.png" rel="icon">
  <link href="img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,500,600,700,700i|Montserrat:300,400,500,600,700" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css"rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate/animate.min.css" rel="stylesheet">
  <link href="lib/ionicons/css/ionicons.min.css" rel="stylesheet">
  <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
  <link href="lib/lightbox/css/lightbox.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

</head>

<body>
  

  <header id="header" class="header-scrolled">

    <div id="topbar">
      <div class="container">
        
      </div>
    </div>

    <div class="container">

      <div class="logo float-left">
	  
        <!-- Uncomment below if you prefer to use an image logo -->
        <h1 class="text-light"><a href="#intro" class="scrollto"><span>PRE- UNI </span></a></h1>
        <!-- <a href="#header" class="scrollto"><img src="img/logo.png" alt="" class="img-fluid"></a> -->
      </div>

      <nav class="main-nav float-right d-none d-lg-block">
	 
        <ul>
		
          <li ><a href="index2.html">INICIO</a></li>
          <li class="active"><a href="Cuestionarios.html">CUESTIONARIOS</a></li>
          <li><a href="Simulador.html">SIMULADOR</a></li>
          <li><a href="Tutorias.html">TUTORIALES</a></li>
          <li><a href="Contactos.html">CONTACTO</a></li>
          <li><a  href="cerrar.php" style="color:#0033FF" >Cerrar Sesi&oacute;n</a></li>
            
              
         
        </ul>
      </nav><!-- .main-nav -->
      
    </div>
  </header><!-- #header -->
  <br><br>
  
 <img src="img/logo.png" style="margin:5px 400px">


	   <seccion id="resultado"> 
	   <div class="contenedor_ts" >
	   
	  <h1 style="color:#006699"; align="center"> <span style="border-width:4px; border-style:none;  border-color:#000000">
	   
	  RESULTADO - TEST DE ORIENTACION VOCACIONAL</span></h1>
	   </div>
	 
	<div class="conte dos">
	<center><h6><b>Según el test Vocacional las carreras ideales para ti son:</b> </h6>
		
<?php
if(!isset($POST_)){

$pregunta1=$_POST['pregunta1'];
$pregunta2=$_POST['pregunta2'];
$pregunta3=$_POST['pregunta3'];
$pregunta4=$_POST['pregunta4'];
$pregunta5=$_POST['pregunta5'];
$pregunta6=$_POST['pregunta6'];
$pregunta7=$_POST['pregunta7'];
$pregunta8=$_POST['pregunta8'];
$pregunta9=$_POST['pregunta9'];
$pregunta10=$_POST['pregunta10'];
$pregunta11=$_POST['pregunta11'];
$pregunta12=$_POST['pregunta12'];
$pregunta13=$_POST['pregunta13'];
$pregunta14=$_POST['pregunta14'];
$pregunta15=$_POST['pregunta15'];
$pregunta16=$_POST['pregunta16'];
$pregunta17=$_POST['pregunta17'];
$pregunta18=$_POST['pregunta18'];
$pregunta19=$_POST['pregunta19'];
$pregunta20=$_POST['pregunta20'];


if($pregunta1=="muchas" && 
$pregunta2=="muchas" &&
$pregunta3=="muchas" &&
$pregunta4=="muchas" &&
$pregunta5=="muchas" &&
$pregunta6=="muchas" &&
$pregunta7=="muchas" &&
$pregunta8=="muchas" &&
$pregunta9=="muchas" &&
$pregunta10=="muchas" &&
$pregunta11=="muchas" &&
$pregunta12=="muchas" &&
$pregunta13=="muchas" &&
$pregunta14=="muchas" &&
$pregunta15=="muchas" &&
$pregunta16=="muchas" &&
$pregunta17=="muchas" &&
$pregunta18=="muchas" &&
$pregunta19=="muchas" &&
$pregunta20=="muchas"){


	echo "INGENIERIA EN MECÁNICA<br><br>";
	echo "INGENIERIA EN INDUSTRIAL<br><br>";
	echo "INGENIERIA EN CIVL<br><br>";
	echo "INGENIERIA EN SISTEMAS<br><br>";
	echo "INGENIERIA EN FINANZAS<br><br>";
	echo "INGENIERIA BIOTECNOLOGÍA<br><br><br>";

	echo "<h6><b>A continuacion te mostramos algunas universidades donde podras encontrar estas carreras:</b></h6>";
     
	echo "UNIVERSIDAD CENTRAL DEL ECUADOR (UCE)<br><br>";
	
	$image= '/imagenes/uce3png.png';
 
	echo '<a href="https://ecuadoruniversitario.com/programas-academicos/universidad-central-del-ecuador-uce-y-su-oferta-academica/" target="_blank"><img src="imagenes/uce3png.png" border="0" /></a><br><br>';
	
	
	echo "UNIVERSIDAD NACIONAL DE CHIMBORAZO (UNACH)<br><br>";
	
	$image= '/imagenes/unach2png.png';
 
	echo '<a href="https://www.cursosycarreras.com.ec/carreras-universitarias-unach-universidad-nacional-del-chimborazo-TI-2-1725" target="_blank"><img src="imagenes/unach2png.png" border="0" /></a><br><br>';
	
	echo "UNIVERSIDAD DE LAS FUERZAS ARMADAS (ESPE)<br><br>";
	
	$image= '/imagenes/espe2png.png';
 
	echo '<a href="https://www.cursosycarreras.com.ec/espe-escuela-politecnica-del-ejercito-FI-1685" target="_blank"><img src="imagenes/espe2png.png" border="0" /></a><br><br><br>';

}else if($pregunta1=="veces" && 
$pregunta2=="veces" &&
$pregunta3=="veces" &&
$pregunta4=="veces" &&
$pregunta5=="veces" &&
$pregunta6=="veces" &&
$pregunta7=="veces" &&
$pregunta8=="veces" &&
$pregunta9=="veces" &&
$pregunta10=="veces" &&
$pregunta11=="veces" &&
$pregunta12=="veces" &&
$pregunta13=="veces" &&
$pregunta14=="veces" &&
$pregunta15=="veces" &&
$pregunta16=="veces" &&
$pregunta17=="veces" &&
$pregunta18=="veces" &&
$pregunta19=="veces" &&
$pregunta20=="veces"){

	
	echo "LICENCIATURA EN EDUCACIÓN<br><br>";
	echo "ABOGADO<br><br>";
	echo "LICENCIATURA EN IDIOMAS<br><br>";
	echo "LICENCIATURA EN TICS<br><br>";
	echo "LICENCIATURA EN COMERCIO<br><br>";
	echo "LICENCIATURA EN ADMINISTRACI&OacuteN<br><br><br>";
	
	echo "<h6><b>A continuacion te mostramos algunas universidades donde podras encontrar estas carreras:</b></h6>";
     
	echo "UNIVERSIDAD CENTRAL DEL ECUADOR (UCE)<br><br>";
	
	$image= '/imagenes/uce3png.png';
 
	echo '<a href="https://ecuadoruniversitario.com/programas-academicos/universidad-central-del-ecuador-uce-y-su-oferta-academica/" target="_blank"><img src="imagenes/uce3png.png" border="0" /></a><br><br><br>';
	

	
	echo "UNIVERSIDAD DE LAS FUERZAS ARMADAS (ESPE)<br><br>";
	
	$image= '/imagenes/espe2png.png';
 
	echo '<a href="https://www.cursosycarreras.com.ec/espe-escuela-politecnica-del-ejercito-FI-1685"target="_blank"><img src="imagenes/espe2png.png" border="0" /></a><br><br><br>';
	
	
	echo "ESCUELA SUPERIOR POLIT&EacuteCNICA DEL LITORAL (ESPOL)<br><br>";
	
	$image= '/imagenes/espol4png.png';
 
	echo '<a href="http://www.espol.edu.ec/es/educacion/grado/catalogo"target="_blank"><img src="imagenes/espol4png.png" border="0" /></a><br><br>';
	
    
	
	
}else {
	echo "FISICA<br><br>";
	echo "QUIMICA<br><br>";
	echo "MATEMATICAS<br><br>";
	echo "GEOLOGIA<br><br>";
	echo "ENFERMERIA<br><br>";
	echo "MEDICINA<br><br><br>";
	echo "<h6><b>A continuacion te mostramos algunas universidades donde podras encontrar estas carreras:</h6></b>";
     
	echo "ESCUELA SUPERIOR POLIT&EacuteCNICA DE CHIMBORAZO (ESPOCH)<br><br>";
	
	$image= '/imagenes/espoch3png.png';
 
	echo '<a href="https://www.espoch.edu.ec/index.php/component/k2/item/873-oferta-acad%C3%A9mica-de-la-espoch-aprobada-por-el-ces.html"target="_blank"><img src="imagenes/espoch3png.png" border="0" /></a><br><br>';
	
	echo "ESCUELA POLIT&EacuteCNICA NACIONAL (EPN)<br><br>";
	
	$image= '/imagenes/epn3png.png';
 
	echo '<a href="https://www.epn.edu.ec/oferta-academica/"target="_blank"><img src="imagenes/epn3png.png" border="0" /></a><br><br>';
	
	
	echo "UNIVERSIDAD T&EacuteCNICA PARTICULAR DE LOJA (UTPL)<br><br>";
	
	$image= '/imagenes/utpl2png.png';
 
	echo '<a href="https://inscripciones.utpl.edu.ec/distancia"target="_blank"><img src="imagenes/utpl2png.png" border="0" /></a><br>';
	
	
}
}



?>
	 </center><br>
	 <div style="text-align:center">
	<a href="Cuestionarios.html#orientacion"> <button type="submint" class="boton azul">VOLVER A REALIZAR TEST</button><br></a>	
	</div>
	   </div>
</section>
	   <br>
	  </br>

  

	  
	  
	    
	   
	    <!--==========================
    Footer
  ============================-->
  <footer id="footer" class="section-bg">
    <div class="footer-top">
      <div class="container">

        <div class="row">

          <div class="col-lg-6">

            <div class="row">

                <div class="col-sm-6">

                  <div class="footer-info">
                    <h3>PRE-UNI</h3>
					<img src="img/logo.png">
                    <p>El mejor sitio web que te ayuda a estudiar y prepararte para rendir el examen "ser bachiller" </p>
                  </div>

                  

                </div>

                <div class="col-sm-6">
                  <div class="footer-links">
                    <h4>Navegador</h4>
                    <ul>
                      <li><a href="index2.html">Inicio</a></li>
                      <li><a href="Cuestionarios.html">Cuestionario</a></li>
                      <li><a href="Simulador.html">Simulador</a></li>
					   <li><a href="Tutorias.html">Tutoriales</a></li>
                      <li><a href="Contactos.html">Contactos</a></li>
                    
                    </ul>
                  </div>

                  <div class="footer-links">
                    <h4>Contactos Us</h4>
                    <p>
                      Universidad de las Fuerzas Armadas ESPE <br>
                      Sede Santo Domingo de los Tsáchilas<br>
                      Ecuador <br>
                      <strong>Telefono:</strong> +593 988 078 264<br>
                      <strong>Email:</strong> kkroman@espe.edu.ec<br>jaaranda1@espe.edu.ec<br>adoniscargua@espe.edu.ec
                    </p>
                  </div>

                  <div class="social-links">
                    <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
                    <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
                    <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
                    <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
                  </div>

                </div>

            </div>

          </div>

          <div class="col-lg-6">

            <div class="form">
              
              <h4>Envianos tu mensaje</h4>
              <p>Responderemos lo mas pronto posible, atento a tu bandeja de entrada.</p>
              <form action="" method="post" role="form" class="contactForm">
                <div class="form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Tu nombre" data-rule="minlen:4" data-msg="Por favor llena el apartado correctamente" />
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Tu correo" data-rule="email" data-msg="Por favor ingresa un correo valido" />
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" name="subject" id="subject" placeholder="Asunto" data-rule="minlen:4" data-msg="Por favor llena el apartado correctamente" />
                  <div class="validation"></div>
                </div>
                <div class="form-group">
                  <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Por favor escribe algo para nosotros" placeholder="Mensaje"></textarea>
                  <div class="validation"></div>
                </div>

                <div id="sendmessage">Tu mensaje se a enviado, Gracias!</div>
                <div id="errormessage"></div>

                <div class="text-center"><button type="submit" title="Send Message">Enviar Mensaje</button></div>
              </form>
            </div>

          </div>

          

        </div>

      </div>
    </div>

    
      
    </div>
  </footer><!-- #footer -->

<a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
<!-- Uncomment below i you want to use a preloader -->
<!-- <div id="preloader"></div> -->

<!-- JavaScript Libraries -->
<script src="lib/jquery/jquery.min.js"></script>
<script src="lib/jquery/jquery-migrate.min.js"></script>
<script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="lib/easing/easing.min.js"></script>
<script src="lib/mobile-nav/mobile-nav.js"></script>
<script src="lib/wow/wow.min.js"></script>
<script src="lib/waypoints/waypoints.min.js"></script>
<script src="lib/counterup/counterup.min.js"></script>
<script src="lib/owlcarousel/owl.carousel.min.js"></script>
<script src="lib/isotope/isotope.pkgd.min.js"></script>
<script src="lib/lightbox/js/lightbox.min.js"></script>
<!-- Contact Form JavaScript File -->
<script src="contactform/contactform.js"></script>

<!-- Template Main Javascript File -->
<script src="js/main.js"></script>
</html>
